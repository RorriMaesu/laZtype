import sqlite3

def setup_db():
    # Connect to the SQLite database (or create it if it doesn't exist)
    conn = sqlite3.connect("settings.db")
    c = conn.cursor()
    
    # Create the settings table if it doesn't exist
    c.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            command_name TEXT PRIMARY KEY,
            state TEXT
        )
    """)
    
    # Create the custom commands table if it doesn't exist
    c.execute("""
        CREATE TABLE IF NOT EXISTS custom_commands (
            voice_command TEXT PRIMARY KEY,
            app_command TEXT
        )
    """)
    
    conn.commit()
    conn.close()

if __name__ == "__main__":
    setup_db()
